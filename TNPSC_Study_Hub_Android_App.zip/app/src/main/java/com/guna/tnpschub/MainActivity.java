package com.guna.tnpschub;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.content.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    TextView title;
    int blue = Color.rgb(13,71,161);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showHome();
    }

    TextView tv(String text, int size) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextSize(size); v.setTextColor(Color.DKGRAY);
        v.setPadding(24,18,24,18);
        return v;
    }

    Button btn(String text) {
        Button b = new Button(this); b.setText(text);
        b.setAllCaps(false); b.setTextSize(17);
        return b;
    }

    void base(String heading) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        title = tv(heading, 24); title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER_VERTICAL); title.setBackgroundColor(blue);
        root.addView(title, new LinearLayout.LayoutParams(-1,70));
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    void addButton(String text, final Runnable action) {
        Button b = btn(text); content.addView(b);
        b.setOnClickListener(v -> action.run());
    }

    void showHome() {
        base("📚 TNPSC Study Hub");
        TextView welcome = tv("Prepare smarter. Practice better. Succeed in TNPSC.",20);
        welcome.setTextColor(blue); content.addView(welcome);
        addButton("📘 Group 1", () -> showGroup("Group 1"));
        addButton("📗 Group 2 & 2A", () -> showGroup("Group 2 & 2A"));
        addButton("📙 Group 4", () -> showGroup("Group 4"));
        addButton("📝 Mock Test / Quiz", this::quiz);
        addButton("📖 Study Materials", this::materials);
        addButton("📰 Current Affairs", this::currentAffairs);
        addButton("💼 Jobs", () -> openUrl("https://www.tnpsc.gov.in/"));
        addButton("ℹ️ About", () -> {
            new AlertDialog.Builder(this).setTitle("TNPSC Study Hub")
                .setMessage("A study companion for TNPSC aspirants. This first Android version includes Groups, study materials, current affairs and a practice quiz.")
                .setPositiveButton("OK", null).show();
        });
    }

    void showGroup(String group) {
        base("📚 " + group);
        content.addView(tv("Select a subject to begin your preparation.",18));
        addButton("Tamil", () -> subject(group,"Tamil"));
        addButton("General Studies", () -> subject(group,"General Studies"));
        addButton("Aptitude & Mental Ability", () -> subject(group,"Aptitude & Mental Ability"));
        addButton("Current Affairs", this::currentAffairs);
        addButton("Mock Test", this::quiz);
        addButton("← Home", this::showHome);
    }

    void subject(String group, String subject) {
        base(subject);
        content.addView(tv(group + " • " + subject,20));
        content.addView(tv("Study notes and practice questions can be added here. This screen is ready for your future TNPSC content.",17));
        addButton("Take Quiz", this::quiz);
        addButton("← Back", () -> showGroup(group));
    }

    void materials() {
        base("📖 Study Materials");
        addButton("Group 1 Materials", () -> subject("Group 1","Study Materials"));
        addButton("Group 2 & 2A Materials", () -> subject("Group 2 & 2A","Study Materials"));
        addButton("Group 4 Materials", () -> subject("Group 4","Study Materials"));
        addButton("Tamil", () -> subject("All Groups","Tamil"));
        addButton("General Studies", () -> subject("All Groups","General Studies"));
        addButton("Aptitude", () -> subject("All Groups","Aptitude"));
        addButton("← Home", this::showHome);
    }

    void currentAffairs() {
        base("📰 Current Affairs");
        content.addView(tv("Daily current affairs section",22));
        content.addView(tv("Add verified TNPSC-relevant national, Tamil Nadu, science, economy, sports and government updates here.",17));
        addButton("TNPSC Website", () -> openUrl("https://www.tnpsc.gov.in/"));
        addButton("← Home", this::showHome);
    }

    void quiz() {
        base("📝 Mock Test");
        final String[] q = {
            "Which is the capital of Tamil Nadu?",
            "What does SQL stand for?",
            "Which body conducts TNPSC examinations?"
        };
        final String[][] opts = {
            {"Chennai","Madurai","Coimbatore","Salem"},
            {"Structured Query Language","Simple Question List","System Query Link","Structured Quick Logic"},
            {"Tamil Nadu Public Service Commission","UPSC","SSC","RRB"}
        };
        final int[] ans = {0,0,0};
        final int[] score = {0};
        showQuestion(q,opts,ans,score,0);
    }

    void showQuestion(String[] q,String[][] opts,int[] ans,int[] score,int i) {
        content.removeAllViews();
        content.addView(tv("Question " + (i+1) + " of " + q.length,18));
        content.addView(tv(q[i],21));
        for(int x=0;x<4;x++){
            Button b=btn(opts[i][x]); content.addView(b);
            final int choice=x;
            b.setOnClickListener(v -> {
                if(choice==ans[i]) score[0]++;
                if(i+1<q.length) showQuestion(q,opts,ans,score,i+1);
                else {
                    content.removeAllViews();
                    content.addView(tv("🎉 Test Complete!",26));
                    content.addView(tv("Your score: "+score[0]+" / "+q.length,22));
                    addButton("Try Again",this::quiz);
                    addButton("← Home",this::showHome);
                }
            });
        }
    }

    void openUrl(String url) {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    }

    @Override public void onBackPressed() {
        showHome();
    }
}
